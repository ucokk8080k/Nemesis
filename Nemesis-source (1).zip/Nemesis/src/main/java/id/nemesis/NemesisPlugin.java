package id.nemesis;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Boss;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Nemesis - mobs that kill players become named nemeses.
 * Uses only the Bukkit API (no Paper-only calls) so it runs on 1.16 - 1.21+.
 */
public final class NemesisPlugin extends JavaPlugin implements Listener {

    private static final Random RND = new Random();

    private static final String[] FIRST = {"Grak", "Mordu", "Zul", "Krunk", "Vex", "Thrag", "Ulfar",
            "Skarn", "Brokk", "Narg", "Drog", "Hexa", "Rotgut", "Bonk", "Ghorm", "Sneek"};
    private static final String[] TITLE = {"the Spineless", "Skullcrusher", "the Unforgiven", "Bonegnawer",
            "the Relentless", "Soulrender", "the Cunning", "Ironjaw", "the Grudgeful", "Doomwhisper"};

    private static final String[] TAUNT_OWNER = {
            "%player%... I remember the taste of your fear.",
            "Back for revenge, %player%? Last time was so easy.",
            "I wear your defeat like a crown, %player%.",
            "Run, %player%. It only makes the hunt sweeter."};
    private static final String[] TAUNT_OTHER = {
            "Another fool wanders into my domain.",
            "Do you know how many I have slain?",
            "Come closer. Let me add you to the list.",
            "Your gear would look lovely on my trophy shelf."};

    private NamespacedKey kOwner, kOwnerName, kName, kLevel, kKills;
    private Attribute aHealth, aDamage, aSpeed;
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Map<String, Long> tauntCooldown = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        kOwner = new NamespacedKey(this, "owner");
        kOwnerName = new NamespacedKey(this, "owner_name");
        kName = new NamespacedKey(this, "name");
        kLevel = new NamespacedKey(this, "level");
        kKills = new NamespacedKey(this, "kills");

        // Attribute names changed in 1.21.3, so look them up by reflection.
        aHealth = attr("MAX_HEALTH", "GENERIC_MAX_HEALTH");
        aDamage = attr("ATTACK_DAMAGE", "GENERIC_ATTACK_DAMAGE");
        aSpeed = attr("MOVEMENT_SPEED", "GENERIC_MOVEMENT_SPEED");

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
    }

    @Override
    public void onDisable() {
        for (BossBar b : bars.values()) b.removeAll();
        bars.clear();
    }

    private Attribute attr(String modern, String legacy) {
        for (String n : new String[]{modern, legacy}) {
            try {
                return (Attribute) Attribute.class.getField(n).get(null);
            } catch (Exception ignored) {
                // try next name
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ events

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent ev) {
        Player victim = ev.getEntity();
        EntityDamageEvent last = victim.getLastDamageCause();
        if (!(last instanceof EntityDamageByEntityEvent)) return;

        Entity src = ((EntityDamageByEntityEvent) last).getDamager();
        if (src instanceof Projectile) {
            ProjectileSource ps = ((Projectile) src).getShooter();
            if (ps instanceof Entity) src = (Entity) ps;
        }
        if (!(src instanceof Mob) || !src.isValid() || src instanceof Boss) return;
        Mob mob = (Mob) src;
        if (getConfig().getStringList("blacklist").contains(mob.getType().name())) return;

        PersistentDataContainer pdc = mob.getPersistentDataContainer();
        Integer stored = pdc.get(kLevel, PersistentDataType.INTEGER);
        int level = stored == null ? 0 : stored;
        boolean fresh = level == 0;
        if (fresh) {
            pdc.set(kName, PersistentDataType.STRING,
                    FIRST[RND.nextInt(FIRST.length)] + " " + TITLE[RND.nextInt(TITLE.length)]);
        }
        level = Math.min(getConfig().getInt("max-level", 10), level + 1);
        Integer k = pdc.get(kKills, PersistentDataType.INTEGER);
        int kills = (k == null ? 0 : k) + 1;
        pdc.set(kLevel, PersistentDataType.INTEGER, level);
        pdc.set(kKills, PersistentDataType.INTEGER, kills);
        pdc.set(kOwner, PersistentDataType.STRING, victim.getUniqueId().toString());
        pdc.set(kOwnerName, PersistentDataType.STRING, victim.getName());

        applyStats(mob, level);

        String name = pdc.get(kName, PersistentDataType.STRING);
        if (fresh) {
            Bukkit.broadcastMessage(ChatColor.DARK_RED + "\u2620 " + ChatColor.RED + name
                    + ChatColor.DARK_RED + " has risen from the death of "
                    + ChatColor.YELLOW + victim.getName() + ChatColor.DARK_RED + "!");
        } else {
            Bukkit.broadcastMessage(ChatColor.DARK_RED + "\u2620 " + ChatColor.RED + name
                    + ChatColor.DARK_RED + " grows stronger! " + ChatColor.GRAY
                    + "(Lv. " + level + ", " + kills + " kills)");
        }
        mob.getWorld().playSound(mob.getLocation(), "entity.wither.spawn", 0.6f, 1.6f);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onMobDeath(EntityDeathEvent ev) {
        LivingEntity le = ev.getEntity();
        if (le instanceof Player) return;
        PersistentDataContainer pdc = le.getPersistentDataContainer();
        Integer lv = pdc.get(kLevel, PersistentDataType.INTEGER);
        if (lv == null) return;
        int level = lv;

        String name = pdc.get(kName, PersistentDataType.STRING);
        if (name == null) name = "Nemesis";
        Integer k = pdc.get(kKills, PersistentDataType.INTEGER);
        int kills = k == null ? 1 : k;
        String owner = pdc.get(kOwner, PersistentDataType.STRING);
        Player killer = le.getKiller();
        String killerName = killer == null ? "the world" : killer.getName();

        BossBar bar = bars.remove(le.getUniqueId());
        if (bar != null) bar.removeAll();

        ev.getDrops().add(trophy(le, name, level, kills, killerName));
        ev.setDroppedExp(ev.getDroppedExp() + level * getConfig().getInt("xp-per-level", 40));

        Bukkit.broadcastMessage(ChatColor.GOLD + "\u2694 " + ChatColor.YELLOW + killerName
                + ChatColor.GOLD + " slew the nemesis " + ChatColor.RED + name
                + ChatColor.GRAY + " (Lv. " + level + ")");

        if (killer != null && killer.getUniqueId().toString().equals(owner)) {
            killer.giveExp(level * getConfig().getInt("revenge-xp-per-level", 50));
            killer.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "REVENGE! "
                    + ChatColor.YELLOW + "Sweet justice. Bonus XP granted.");
            killer.playSound(killer.getLocation(), "ui.toast.challenge_complete", 1f, 1f);
        }
    }

    // ----------------------------------------------------------------- logic

    private boolean isNemesis(Entity e) {
        return e instanceof Mob
                && e.getPersistentDataContainer().has(kLevel, PersistentDataType.INTEGER);
    }

    private void applyStats(Mob mob, int level) {
        double hp = 1 + level * getConfig().getDouble("health-per-level", 0.25);
        double dmg = 1 + level * getConfig().getDouble("damage-per-level", 0.12);
        double spd = 1 + Math.min(level * 0.02, 0.2);
        scale(mob, aHealth, hp);
        scale(mob, aDamage, dmg);
        scale(mob, aSpeed, spd);

        if (aHealth != null) {
            AttributeInstance h = mob.getAttribute(aHealth);
            if (h != null) mob.setHealth(h.getValue());
        }

        EntityEquipment eq = mob.getEquipment();
        if (eq != null && level >= 2) {
            String h = level >= 9 ? "NETHERITE_HELMET"
                    : level >= 6 ? "DIAMOND_HELMET"
                    : level >= 4 ? "IRON_HELMET" : "CHAINMAIL_HELMET";
            Material m = Material.getMaterial(h);
            if (m == null) m = Material.DIAMOND_HELMET;
            eq.setHelmet(new ItemStack(m));
            eq.setHelmetDropChance(0f);
        }

        mob.setPersistent(true);
        mob.setRemoveWhenFarAway(false);
        mob.setCustomNameVisible(true);
        mob.setGlowing(getConfig().getBoolean("glowing", true));
        mob.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,
                Integer.MAX_VALUE, 0, false, false));
        mob.setCustomName(displayName(mob));
    }

    private void scale(Mob mob, Attribute attr, double mult) {
        if (attr == null) return;
        AttributeInstance in = mob.getAttribute(attr);
        if (in != null) in.setBaseValue(in.getDefaultValue() * mult);
    }

    private String rank(int level) {
        if (level < 3) return "Grunt";
        if (level < 5) return "Captain";
        if (level < 8) return "Warlord";
        return "Overlord";
    }

    private String displayName(Mob mob) {
        PersistentDataContainer pdc = mob.getPersistentDataContainer();
        Integer lv = pdc.get(kLevel, PersistentDataType.INTEGER);
        int level = lv == null ? 1 : lv;
        String name = pdc.get(kName, PersistentDataType.STRING);
        if (name == null) name = "Nemesis";
        return ChatColor.RED + name + ChatColor.GRAY + " [Lv." + level + " " + rank(level) + "]";
    }

    private ItemStack trophy(LivingEntity le, String name, int level, int kills, String killer) {
        Material m;
        switch (le.getType().name()) {
            case "ZOMBIE":
            case "HUSK":
            case "DROWNED":
            case "ZOMBIE_VILLAGER":
                m = Material.ZOMBIE_HEAD;
                break;
            case "SKELETON":
            case "STRAY":
                m = Material.SKELETON_SKULL;
                break;
            case "WITHER_SKELETON":
                m = Material.WITHER_SKELETON_SKULL;
                break;
            default:
                m = Material.NETHER_STAR;
        }
        ItemStack item = new ItemStack(m);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.GOLD + "Trophy of " + name);
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.RED + "Level " + level + " " + rank(level));
            lore.add(ChatColor.GRAY + "Victims claimed: " + kills);
            lore.add(ChatColor.YELLOW + "Slain by " + killer);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    /** Runs every second: boss bars and taunts for nemeses near players. */
    private void tick() {
        double barR = getConfig().getDouble("bossbar-radius", 40);
        double tauntR = getConfig().getDouble("taunt-radius", 12);
        long cd = getConfig().getLong("taunt-cooldown-seconds", 25) * 1000L;
        long now = System.currentTimeMillis();

        Map<UUID, Mob> mobs = new HashMap<>();
        Map<UUID, Set<UUID>> viewers = new HashMap<>();

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isDead()) continue;
            for (Entity e : p.getNearbyEntities(barR, barR, barR)) {
                if (!isNemesis(e) || !e.isValid()) continue;
                Mob m = (Mob) e;
                UUID id = m.getUniqueId();
                mobs.put(id, m);
                Set<UUID> set = viewers.get(id);
                if (set == null) {
                    set = new HashSet<>();
                    viewers.put(id, set);
                }
                set.add(p.getUniqueId());

                if (m.getLocation().distanceSquared(p.getLocation()) <= tauntR * tauntR) {
                    String key = id + ":" + p.getUniqueId();
                    Long last = tauntCooldown.get(key);
                    if (last == null || now - last > cd) {
                        tauntCooldown.put(key, now);
                        String owner = m.getPersistentDataContainer().get(kOwner, PersistentDataType.STRING);
                        boolean personal = p.getUniqueId().toString().equals(owner);
                        String[] pool = personal ? TAUNT_OWNER : TAUNT_OTHER;
                        String line = pool[RND.nextInt(pool.length)].replace("%player%", p.getName());
                        String name = m.getPersistentDataContainer().get(kName, PersistentDataType.STRING);
                        p.sendMessage(ChatColor.DARK_RED + (name == null ? "Nemesis" : name)
                                + ChatColor.GRAY + ": " + line);
                        p.playSound(m.getLocation(), "entity.ravager.roar", 0.4f, 0.8f);
                    }
                }
            }
        }

        for (Map.Entry<UUID, Mob> en : mobs.entrySet()) {
            UUID id = en.getKey();
            Mob m = en.getValue();
            BossBar bar = bars.get(id);
            if (bar == null) {
                bar = Bukkit.createBossBar(displayName(m), BarColor.RED, BarStyle.SEGMENTED_10);
                bars.put(id, bar);
            }
            bar.setTitle(displayName(m));
            double max = m.getHealth();
            if (aHealth != null) {
                AttributeInstance mh = m.getAttribute(aHealth);
                if (mh != null) max = mh.getValue();
            }
            double prog = max <= 0 ? 0 : m.getHealth() / max;
            bar.setProgress(Math.max(0, Math.min(1, prog)));

            Set<UUID> near = viewers.get(id);
            for (Player v : new ArrayList<>(bar.getPlayers())) {
                if (!near.contains(v.getUniqueId())) bar.removePlayer(v);
            }
            for (UUID u : near) {
                Player v = Bukkit.getPlayer(u);
                if (v != null) bar.addPlayer(v);
            }
        }

        Iterator<Map.Entry<UUID, BossBar>> it = bars.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, BossBar> en = it.next();
            if (!mobs.containsKey(en.getKey())) {
                en.getValue().removeAll();
                it.remove();
            }
        }
        if (tauntCooldown.size() > 500) tauntCooldown.clear();
    }

    // ---------------------------------------------------------------- command

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (args.length > 0) {
            if (!s.hasPermission("nemesis.admin")) {
                s.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            switch (args[0].toLowerCase()) {
                case "reload":
                    reloadConfig();
                    s.sendMessage(ChatColor.GREEN + "Nemesis reloaded.");
                    break;
                case "clear": {
                    int n = 0;
                    for (World w : Bukkit.getWorlds()) {
                        for (LivingEntity le : w.getLivingEntities()) {
                            if (isNemesis(le)) {
                                le.remove();
                                n++;
                            }
                        }
                    }
                    s.sendMessage(ChatColor.GREEN + "Removed " + n + " loaded nemeses.");
                    break;
                }
                case "list": {
                    int n = 0;
                    for (World w : Bukkit.getWorlds()) {
                        for (LivingEntity le : w.getLivingEntities()) {
                            if (!isNemesis(le)) continue;
                            n++;
                            Location l = le.getLocation();
                            s.sendMessage(displayName((Mob) le) + ChatColor.DARK_GRAY + " @ " + w.getName()
                                    + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ());
                        }
                    }
                    s.sendMessage(ChatColor.GOLD + "Active nemeses: " + n);
                    break;
                }
                default:
                    s.sendMessage(ChatColor.GRAY + "/nemesis [list|clear|reload]");
            }
            return true;
        }

        if (!(s instanceof Player)) {
            s.sendMessage("Players only. Use /nemesis list");
            return true;
        }
        Player p = (Player) s;
        boolean any = false;
        for (Entity e : p.getNearbyEntities(100, 100, 100)) {
            if (!isNemesis(e)) continue;
            String owner = e.getPersistentDataContainer().get(kOwner, PersistentDataType.STRING);
            if (!p.getUniqueId().toString().equals(owner)) continue;
            any = true;
            int dist = (int) e.getLocation().distance(p.getLocation());
            p.sendMessage(displayName((Mob) e) + ChatColor.GRAY + " - " + dist + " blocks away");
        }
        if (!any) p.sendMessage(ChatColor.GRAY + "No nemesis is hunting you nearby. Yet.");
        return true;
    }
}
