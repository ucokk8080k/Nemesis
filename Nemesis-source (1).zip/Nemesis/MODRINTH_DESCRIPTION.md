# ☠ Nemesis: Mobs That Remember

**What if the zombie that killed you didn't just forget about it?**

In Nemesis, any mob that kills a player is **promoted to a named Nemesis**. It gets a name, a rank, a boss bar, better gear, and **grows stronger with every kill**. It taunts you when you come near. And when you finally take it down, you earn a **trophy** and **revenge XP**.

Inspired by the legendary Nemesis System from *Middle-earth: Shadow of Mordor*, now on your Minecraft server.

---

## 🔥 How it works

1. A Zombie kills you. The server announces: **"☠ Grak the Spineless has risen!"**
2. Grak keeps its name, gets **+25% health, +12% damage** and a **chainmail helmet**.
3. Every player it kills makes it **level up** (up to Lv. 10, Overlord rank).
4. Get close and Grak taunts you personally: *"Back for revenge? Last time was so easy."*
5. Defeat it to claim a **Trophy of Grak the Spineless**, bonus XP, and a **REVENGE** bonus if you were its victim.

---

## ✨ Features

- 🏷 **Unique names & ranks**: Grunt → Captain → Warlord → Overlord
- 📈 **Real progression**: health, damage, speed and armor scale with level
- 🩸 **Boss bar** appears when a nemesis is nearby
- 💬 **Personalized taunts** aimed at their latest victim
- 🏆 **Collectible trophies** with name, level and kill count in the lore
- ⚔ **Revenge bonus XP** for killing the mob that killed you
- ✨ Nemeses **glow**, so hunting them down is part of the fun
- 🔥 Fire resistant: they won't burn away in daylight
- 💾 **Survives restarts**: all data lives on the mob itself, no database needed
- ⚙ Fully configurable scaling, XP, radius and blacklist

---

## 🎮 Commands

| Command | Description | Permission |
|---|---|---|
| `/nemesis` | See which nemeses are hunting you and how far away they are | none |
| `/nemesis list` | List all active nemeses | `nemesis.admin` |
| `/nemesis clear` | Remove all loaded nemeses | `nemesis.admin` |
| `/nemesis reload` | Reload the config | `nemesis.admin` |

---

## 📦 Requirements

- **Spigot / Paper / Purpur 1.16.5 - 1.21.x** (all versions in between)
- **Java 8+** (whatever your server already uses)
- No dependencies

---

## 💡 Perfect for

Survival, SMP, hardcore and PvE servers where death should feel like a story, not a setback.

*Every server has a Nemesis. Who is yours?* ⭐ Follow to support!
